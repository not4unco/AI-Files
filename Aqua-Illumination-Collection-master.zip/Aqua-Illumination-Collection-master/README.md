# Aqua Illumination Collection

Here, I have collected many different Aqua Illumination presets, to be used with the Aqua Illumination Hydra 26HD/52HD.
For most presets, the file name also reflects the original author. Unfortunately, for some presets I could no longer trace back where they come from.

Please be advised that I have collected these presets from many different sources (facebook / reef2reef etc), and that I'm not responsible for any damage these might do to your corals. Some presets might have been designed with a very specific goal in mind and might not suit your specific setup or taste. In short:

## USE THE PRESETS AT YOUR OWN RISK AND DISCRETION.

If you find your preset here and want it removed, please send me a message.

# Downloading
Click in the top right on clone/download and choose option 'download zip'

# Updates
24-09-2018 - Added 38 presets pulled from the Aqua Illumination Users group at Facebook. User names are added to the file names, to reflect authorship. <br/><br/>
22-09-2018 - First upload / start of the repository
